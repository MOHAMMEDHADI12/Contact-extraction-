import { useState, useRef } from "react";
import { Upload, FileText, X, Loader2, Image } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FileUploaderProps {
  onFileSelect: (file: File) => void;
  isLoading: boolean;
}

const ACCEPTED_FORMATS = [
  ".txt", ".csv", ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".json", ".xml", ".html", ".png", ".jpg", ".jpeg", ".gif", ".webp"
];

export function FileUploader({ onFileSelect, isLoading }: FileUploaderProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      onFileSelect(file);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      onFileSelect(file);
    }
  };

  const handleButtonClick = () => {
    inputRef.current?.click();
  };

  const clearFile = () => {
    setSelectedFile(null);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const isImage = (fileName: string) => {
    const ext = fileName.toLowerCase().split('.').pop() || "";
    return ["png", "jpg", "jpeg", "gif", "webp"].includes(ext);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh]">
      <div
        className={`w-full max-w-md border-2 border-dashed rounded-lg p-8 text-center transition-all cursor-pointer ${
          dragActive
            ? "border-primary bg-primary/5 scale-[1.02]"
            : "border-border hover:border-primary/50 hover:bg-secondary/30"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={!selectedFile ? handleButtonClick : undefined}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED_FORMATS.join(",")}
          onChange={handleChange}
          className="hidden"
          data-testid="input-file-upload"
        />

        {selectedFile ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3 p-4 bg-secondary/50 rounded-lg">
              {isImage(selectedFile.name) ? (
                <Image className="h-8 w-8 text-primary" />
              ) : (
                <FileText className="h-8 w-8 text-primary" />
              )}
              <div className="text-right flex-1 min-w-0">
                <p className="font-medium text-foreground truncate" data-testid="text-file-name">
                  {selectedFile.name}
                </p>
                <p className="text-sm text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
              </div>
              {!isLoading && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={(e) => { e.stopPropagation(); clearFile(); }}
                  data-testid="button-clear-file"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            {isLoading && (
              <div className="flex items-center justify-center gap-2 text-primary">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span className="text-sm">جاري الاستخراج...</span>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Upload className="h-8 w-8 text-primary" />
            </div>
            <div>
              <p className="text-lg font-medium text-foreground">
                اسحب الملف هنا
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                أو اضغط للاختيار
              </p>
            </div>
          </div>
        )}
      </div>
      
      <p className="text-xs text-muted-foreground mt-4 text-center">
        PDF, Word, Excel, صور, TXT, CSV
      </p>
    </div>
  );
}
