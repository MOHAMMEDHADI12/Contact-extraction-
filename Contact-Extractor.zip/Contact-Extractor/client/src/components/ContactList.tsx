import { useState } from "react";
import { Copy, Check, MessageCircle, Search, ArrowRight, User, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import type { Contact } from "@shared/schema";

interface ContactListProps {
  contacts: Contact[];
  fileName: string;
  onNewUpload: () => void;
}

const QUICK_MESSAGES = [
  "السلام عليكم",
  "مرحباً",
  "شكراً",
];

export function ContactList({ contacts, fileName, onNewUpload }: ContactListProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.phone.includes(searchQuery)
  );

  const copyToClipboard = async (phone: string, id: string) => {
    try {
      await navigator.clipboard.writeText(phone);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      toast({
        title: "فشل النسخ",
        variant: "destructive",
      });
    }
  };

  const formatPhoneForWhatsApp = (phone: string): string => {
    let cleanPhone = phone.replace(/[\s\-\(\)+]/g, "");
    // Convert Saudi local format (05xxxxxxxx) to international (9665xxxxxxxx)
    if (cleanPhone.startsWith("05") && cleanPhone.length === 10) {
      cleanPhone = "966" + cleanPhone.substring(1);
    }
    // Remove leading zeros for other formats
    if (cleanPhone.startsWith("00")) {
      cleanPhone = cleanPhone.substring(2);
    }
    return cleanPhone;
  };

  const openWhatsApp = (phone: string, msg?: string) => {
    const formattedPhone = formatPhoneForWhatsApp(phone);
    const url = msg 
      ? `https://wa.me/${formattedPhone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/${formattedPhone}`;
    window.open(url, "_blank");
  };

  const copyAllNumbers = async () => {
    const allNumbers = contacts.map((c) => c.phone).join("\n");
    try {
      await navigator.clipboard.writeText(allNumbers);
      toast({
        title: "تم نسخ جميع الأرقام",
        description: `${contacts.length} رقم`,
      });
    } catch {
      toast({
        title: "فشل النسخ",
        variant: "destructive",
      });
    }
  };

  const handleSendMessage = () => {
    if (selectedContact) {
      openWhatsApp(selectedContact.phone, message);
      setSelectedContact(null);
      setMessage("");
    }
  };

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onNewUpload}
              data-testid="button-new-upload"
            >
              <ArrowRight className="h-4 w-4" />
            </Button>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-foreground">الأرقام</h2>
                <Badge variant="secondary" data-testid="badge-contacts-count">
                  {contacts.length}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">{fileName}</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={copyAllNumbers}
            data-testid="button-copy-all"
          >
            <Copy className="h-4 w-4 ml-1" />
            نسخ الكل
          </Button>
        </div>

        {contacts.length > 5 && (
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-9"
              data-testid="input-search-contacts"
            />
          </div>
        )}

        <div className="space-y-1 max-h-[50vh] overflow-y-auto">
          {filteredContacts.map((contact) => (
            <div
              key={contact.id}
              className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 hover-elevate"
              data-testid={`contact-row-${contact.id}`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="h-4 w-4 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate" data-testid={`text-name-${contact.id}`}>
                    {contact.name}
                  </p>
                  <p className="text-xs text-muted-foreground font-mono" dir="ltr" data-testid={`text-phone-${contact.id}`}>
                    {contact.phone}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => copyToClipboard(contact.phone, contact.id)}
                  data-testid={`button-copy-${contact.id}`}
                >
                  {copiedId === contact.id ? (
                    <Check className="h-4 w-4 text-primary" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
                <Button
                  size="icon"
                  variant="default"
                  className="bg-[#25D366] hover:bg-[#20bd5a]"
                  onClick={() => setSelectedContact(contact)}
                  data-testid={`button-whatsapp-${contact.id}`}
                >
                  <MessageCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {filteredContacts.length === 0 && searchQuery && (
          <p className="text-center py-4 text-sm text-muted-foreground">
            لا توجد نتائج
          </p>
        )}
      </div>

      <Dialog open={!!selectedContact} onOpenChange={() => setSelectedContact(null)}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-[#25D366]" />
              إرسال رسالة
            </DialogTitle>
          </DialogHeader>
          
          {selectedContact && (
            <div className="space-y-4">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="font-medium">{selectedContact.name}</p>
                <p className="text-sm text-muted-foreground font-mono" dir="ltr">
                  {selectedContact.phone}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {QUICK_MESSAGES.map((msg) => (
                  <Button
                    key={msg}
                    variant="outline"
                    size="sm"
                    onClick={() => setMessage(msg)}
                    className="text-xs"
                  >
                    {msg}
                  </Button>
                ))}
              </div>

              <Textarea
                placeholder="اكتب رسالتك..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={2}
                className="resize-none"
              />

              <div className="flex gap-2">
                <Button
                  onClick={handleSendMessage}
                  className="flex-1 bg-[#25D366] hover:bg-[#20bd5a]"
                >
                  <Send className="h-4 w-4 ml-2" />
                  إرسال
                </Button>
                <Button
                  variant="outline"
                  onClick={() => openWhatsApp(selectedContact.phone)}
                >
                  فتح المحادثة
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
