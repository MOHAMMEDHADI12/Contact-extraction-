import { useState } from "react";
import { Send, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { Contact } from "@shared/schema";

interface WhatsAppBulkSenderProps {
  contacts: Contact[];
}

const QUICK_MESSAGES = [
  "السلام عليكم",
  "مرحباً، كيف حالك؟",
  "شكراً لك",
  "أحتاج مساعدتك",
];

export function WhatsAppBulkSender({ contacts }: WhatsAppBulkSenderProps) {
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const formatPhoneForWhatsApp = (phone: string): string => {
    let cleanPhone = phone.replace(/[\s\-\(\)+]/g, "");
    // Convert Saudi local format (05xxxxxxxx) to international (9665xxxxxxxx)
    if (cleanPhone.startsWith("05") && cleanPhone.length === 10) {
      cleanPhone = "966" + cleanPhone.substring(1);
    }
    // Remove leading zeros for other formats
    if (cleanPhone.startsWith("00")) {
      cleanPhone = cleanPhone.substring(2);
    }
    return cleanPhone;
  };

  const sendToAll = () => {
    if (!message.trim()) {
      toast({
        title: "اكتب رسالة أولاً",
        variant: "destructive",
      });
      return;
    }

    const encodedMessage = encodeURIComponent(message);
    
    contacts.forEach((contact, index) => {
      const formattedPhone = formatPhoneForWhatsApp(contact.phone);
      setTimeout(() => {
        window.open(`https://wa.me/${formattedPhone}?text=${encodedMessage}`, "_blank");
      }, index * 500);
    });

    toast({
      title: "جاري فتح المحادثات",
      description: `${contacts.length} محادثة`,
    });
  };

  const selectQuickMessage = (msg: string) => {
    setMessage(msg);
  };

  if (contacts.length === 0) return null;

  return (
    <div className="space-y-3 p-4 bg-[#25D366]/5 border border-[#25D366]/20 rounded-lg">
      <div className="flex items-center gap-2 text-[#25D366]">
        <MessageCircle className="h-5 w-5" />
        <span className="font-medium">رسالة واتساب جماعية</span>
      </div>
      
      <div className="flex flex-wrap gap-2">
        {QUICK_MESSAGES.map((msg) => (
          <Button
            key={msg}
            variant="outline"
            size="sm"
            onClick={() => selectQuickMessage(msg)}
            className="text-xs"
            data-testid={`button-quick-${msg.slice(0, 10)}`}
          >
            {msg}
          </Button>
        ))}
      </div>

      <Textarea
        placeholder="أو اكتب رسالتك هنا..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        rows={2}
        className="resize-none bg-background"
        data-testid="textarea-bulk-message"
      />
      
      <Button
        onClick={sendToAll}
        className="w-full bg-[#25D366] hover:bg-[#20bd5a]"
        data-testid="button-send-bulk"
      >
        <Send className="h-4 w-4 ml-2" />
        إرسال للجميع ({contacts.length})
      </Button>
      
      <p className="text-xs text-muted-foreground text-center">
        سيتم فتح واتساب لكل رقم
      </p>
    </div>
  );
}
