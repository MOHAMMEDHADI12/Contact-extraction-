import { useState } from "react";
import { Phone } from "lucide-react";
import { FileUploader } from "@/components/FileUploader";
import { ContactList } from "@/components/ContactList";
import { WhatsAppBulkSender } from "@/components/WhatsAppBulkSender";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useToast } from "@/hooks/use-toast";
import type { Contact, UploadResponse } from "@shared/schema";

export default function Home() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [fileName, setFileName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleFileSelect = async (file: File) => {
    setIsLoading(true);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/extract", {
        method: "POST",
        body: formData,
      });

      const result: UploadResponse = await response.json();

      if (result.success && result.data) {
        setContacts(result.data.contacts);
        setFileName(result.data.fileName);
        toast({
          title: "تم الاستخراج بنجاح",
          description: `تم العثور على ${result.data.contacts.length} رقم جوال`,
        });
      } else {
        toast({
          title: "فشل الاستخراج",
          description: result.error || "حدث خطأ أثناء معالجة الملف",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "خطأ في الاتصال",
        description: "حدث خطأ أثناء الاتصال بالخادم",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewUpload = () => {
    setContacts([]);
    setFileName("");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col" dir="rtl">
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold text-foreground">مستخرج الأرقام</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {contacts.length === 0 ? (
            <FileUploader onFileSelect={handleFileSelect} isLoading={isLoading} />
          ) : (
            <>
              <ContactList 
                contacts={contacts} 
                fileName={fileName} 
                onNewUpload={handleNewUpload}
              />
              <WhatsAppBulkSender contacts={contacts} />
            </>
          )}
        </div>
      </main>
    </div>
  );
}
