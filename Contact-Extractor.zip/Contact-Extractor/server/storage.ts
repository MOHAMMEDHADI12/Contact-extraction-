import type { Contact } from "@shared/schema";

export interface IStorage {
  saveExtraction(contacts: Contact[], fileName: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private extractions: Map<string, { contacts: Contact[]; fileName: string }>;

  constructor() {
    this.extractions = new Map();
  }

  async saveExtraction(contacts: Contact[], fileName: string): Promise<void> {
    const id = Date.now().toString();
    this.extractions.set(id, { contacts, fileName });
  }
}

export const storage = new MemStorage();
