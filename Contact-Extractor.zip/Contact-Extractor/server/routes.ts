import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { randomUUID } from "crypto";
import type { Contact, UploadResponse } from "@shared/schema";
import ExcelJS from "exceljs";
import { GoogleGenAI } from "@google/genai";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

const SUPPORTED_EXTENSIONS = ["txt", "csv", "pdf", "doc", "docx", "xls", "xlsx", "json", "xml", "html", "htm", "png", "jpg", "jpeg", "gif", "webp"];

const ai = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY,
  httpOptions: {
    apiVersion: "",
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
  },
});

function isValidPhoneNumber(phone: string): boolean {
  const cleanPhone = phone.replace(/[-.\s\(\)]/g, "");
  
  if (cleanPhone.length < 9 || cleanPhone.length > 15) return false;
  if (!/^\+?\d+$/.test(cleanPhone)) return false;
  
  if (/^0{3,}/.test(cleanPhone)) return false;
  if (/^1{6,}/.test(cleanPhone)) return false;
  if (/^(\d)\1{7,}$/.test(cleanPhone)) return false;
  
  const saudiPatterns = [
    /^05\d{8}$/,
    /^5\d{8}$/,
    /^9665\d{8}$/,
    /^\+9665\d{8}$/,
    /^009665\d{8}$/,
  ];
  
  const internationalPattern = /^\+?\d{10,15}$/;
  
  const isSaudi = saudiPatterns.some(p => p.test(cleanPhone));
  const isInternational = internationalPattern.test(cleanPhone);
  
  return isSaudi || isInternational;
}

function extractPhoneFromText(text: string): string | null {
  const patterns = [
    /(\+9665\d{8})/,
    /(009665\d{8})/,
    /(9665\d{8})/,
    /(05\d{8})/,
    /(\+\d{1,4}[-.\s]?\d{6,12})/,
    /(\d{10,12})/,
  ];
  
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      const phone = match[1].replace(/[-.\s\(\)]/g, "");
      if (isValidPhoneNumber(phone)) {
        return phone;
      }
    }
  }
  return null;
}

function extractContactsFromStructuredData(rows: string[][]): Contact[] {
  const contacts: Contact[] = [];
  const foundPhones = new Set<string>();
  
  if (rows.length === 0) return contacts;
  
  const header = rows[0].map(h => h?.toLowerCase?.() || "");
  let phoneColIndex = -1;
  let nameColIndex = -1;
  
  const phoneKeywords = ["phone", "mobile", "tel", "جوال", "رقم", "هاتف", "موبايل", "الجوال", "الهاتف"];
  const nameKeywords = ["name", "اسم", "الاسم", "contact", "جهة"];
  
  for (let i = 0; i < header.length; i++) {
    const h = header[i];
    if (phoneKeywords.some(k => h.includes(k))) {
      phoneColIndex = i;
    }
    if (nameKeywords.some(k => h.includes(k))) {
      nameColIndex = i;
    }
  }
  
  const startRow = phoneColIndex >= 0 || nameColIndex >= 0 ? 1 : 0;
  
  for (let i = startRow; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) continue;
    
    let phone: string | null = null;
    let name = "جهة اتصال";
    
    if (phoneColIndex >= 0 && row[phoneColIndex]) {
      const cellValue = String(row[phoneColIndex]).trim();
      phone = extractPhoneFromText(cellValue);
      
      if (nameColIndex >= 0 && row[nameColIndex]) {
        name = String(row[nameColIndex]).trim();
      } else {
        for (let j = 0; j < row.length; j++) {
          if (j !== phoneColIndex && row[j]) {
            const val = String(row[j]).trim();
            if (val && val.length >= 2 && !/^\d+$/.test(val)) {
              name = val;
              break;
            }
          }
        }
      }
    } else {
      for (let j = 0; j < row.length; j++) {
        const cellValue = String(row[j] || "").trim();
        const extracted = extractPhoneFromText(cellValue);
        if (extracted) {
          phone = extracted;
          for (let k = 0; k < row.length; k++) {
            if (k !== j && row[k]) {
              const val = String(row[k]).trim();
              if (val && val.length >= 2 && !/^\d+$/.test(val)) {
                name = val;
                break;
              }
            }
          }
          break;
        }
      }
    }
    
    if (phone && !foundPhones.has(phone)) {
      foundPhones.add(phone);
      
      if (name.length > 50) {
        name = name.substring(0, 50) + "...";
      }
      
      contacts.push({
        id: randomUUID(),
        name: name || "جهة اتصال",
        phone: phone,
      });
    }
  }
  
  return contacts;
}

function extractPhoneNumbers(text: string): Contact[] {
  const contacts: Contact[] = [];
  const foundPhones = new Set<string>();
  const lines = text.split(/\n|\r/).filter(l => l.trim());

  for (const line of lines) {
    const phone = extractPhoneFromText(line);
    
    if (phone && !foundPhones.has(phone)) {
      foundPhones.add(phone);
      
      let name = line.replace(new RegExp(phone.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), "").trim();
      name = name.replace(/[:\-,;|+\(\)]/g, " ").replace(/\s+/g, " ").trim();
      
      if (!name || name.length < 2 || /^\d+$/.test(name)) {
        name = "جهة اتصال";
      }
      
      if (name.length > 50) {
        name = name.substring(0, 50) + "...";
      }

      contacts.push({
        id: randomUUID(),
        name: name,
        phone: phone,
      });
    }
  }

  return contacts;
}

async function extractTextFromImage(buffer: Buffer, mimeType: string): Promise<string> {
  const base64Data = buffer.toString("base64");
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data,
            },
          },
          {
            text: "استخرج جميع أرقام الهواتف والأسماء المرتبطة بها من هذه الصورة. أعطني النتائج بهذا الشكل: اسم: رقم (كل جهة اتصال في سطر منفصل). إذا لم يكن هناك اسم، اكتب 'جهة اتصال' بدلاً منه.",
          },
        ],
      },
    ],
  });

  return response.text || "";
}

async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  const base64Data = buffer.toString("base64");
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "application/pdf",
              data: base64Data,
            },
          },
          {
            text: "استخرج جميع أرقام الهواتف والأسماء المرتبطة بها من هذا الملف. أعطني النتائج بهذا الشكل: اسم: رقم (كل جهة اتصال في سطر منفصل). إذا لم يكن هناك اسم، اكتب 'جهة اتصال' بدلاً منه.",
          },
        ],
      },
    ],
  });

  return response.text || "";
}

async function extractFromFile(buffer: Buffer, mimeType: string, fileName: string): Promise<Contact[]> {
  const extension = fileName.toLowerCase().split('.').pop() || "";
  
  if (!SUPPORTED_EXTENSIONS.includes(extension)) {
    throw new Error(`صيغة الملف غير مدعومة: ${extension}`);
  }
  
  // Image files - use Gemini OCR
  if (["png", "jpg", "jpeg", "gif", "webp"].includes(extension)) {
    const text = await extractTextFromImage(buffer, mimeType);
    return extractPhoneNumbers(text);
  }
  
  // Excel .xlsx files (using ExcelJS)
  if (mimeType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      extension === "xlsx") {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    const allContacts: Contact[] = [];
    
    workbook.eachSheet((sheet) => {
      const rows: string[][] = [];
      sheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
        const rowValues: string[] = [];
        const colCount = sheet.columnCount || row.cellCount;
        for (let i = 1; i <= colCount; i++) {
          const cell = row.getCell(i);
          rowValues.push(cell.value?.toString() || "");
        }
        rows.push(rowValues);
      });
      const contacts = extractContactsFromStructuredData(rows);
      allContacts.push(...contacts);
    });
    
    return allContacts;
  }
  
  // Legacy Excel .xls files - use Gemini AI for extraction
  if (mimeType === "application/vnd.ms-excel" || extension === "xls") {
    const base64Data = buffer.toString("base64");
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: "application/vnd.ms-excel",
                data: base64Data,
              },
            },
            {
              text: "استخرج جميع أرقام الهواتف والأسماء المرتبطة بها من هذا الملف. أعطني النتائج بهذا الشكل: اسم: رقم (كل جهة اتصال في سطر منفصل). إذا لم يكن هناك اسم، اكتب 'جهة اتصال' بدلاً منه.",
            },
          ],
        },
      ],
    });
    return extractPhoneNumbers(response.text || "");
  }
  
  // CSV files
  if (mimeType === "text/csv" || extension === "csv") {
    const text = buffer.toString("utf-8");
    const rows = text.split(/\r?\n/).map(line => line.split(",").map(cell => cell.trim().replace(/^"|"$/g, "")));
    return extractContactsFromStructuredData(rows);
  }
  
  // PDF files - use Gemini
  if (mimeType === "application/pdf" || extension === "pdf") {
    const text = await extractTextFromPDF(buffer);
    return extractPhoneNumbers(text);
  }
  
  // Word files - use Gemini
  if (mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || 
      extension === "docx" || extension === "doc") {
    const mammoth = await import("mammoth");
    const result = await mammoth.extractRawText({ buffer });
    return extractPhoneNumbers(result.value);
  }
  
  // JSON files
  if (mimeType === "application/json" || extension === "json") {
    try {
      const jsonData = JSON.parse(buffer.toString("utf-8"));
      const text = JSON.stringify(jsonData, null, 2);
      return extractPhoneNumbers(text);
    } catch {
      throw new Error("ملف JSON غير صالح");
    }
  }
  
  // XML files
  if (mimeType === "text/xml" || mimeType === "application/xml" || extension === "xml") {
    const text = buffer.toString("utf-8");
    return extractPhoneNumbers(text);
  }
  
  // HTML files
  if (mimeType === "text/html" || extension === "html" || extension === "htm") {
    const text = buffer.toString("utf-8").replace(/<[^>]*>/g, " ");
    return extractPhoneNumbers(text);
  }
  
  // Plain text
  const text = buffer.toString("utf-8");
  return extractPhoneNumbers(text);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/extract", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        const response: UploadResponse = {
          success: false,
          error: "لم يتم رفع أي ملف",
        };
        return res.status(400).json(response);
      }

      const { buffer, mimetype, originalname } = req.file;
      
      const extension = originalname.toLowerCase().split('.').pop() || "";
      if (!SUPPORTED_EXTENSIONS.includes(extension)) {
        const response: UploadResponse = {
          success: false,
          error: `صيغة الملف غير مدعومة. الصيغ المدعومة: ${SUPPORTED_EXTENSIONS.join(", ")}`,
        };
        return res.status(400).json(response);
      }

      const contacts = await extractFromFile(buffer, mimetype, originalname);

      const response: UploadResponse = {
        success: true,
        data: {
          contacts,
          fileName: originalname,
          extractedAt: new Date().toISOString(),
        },
      };

      res.json(response);
    } catch (error) {
      console.error("Error extracting from file:", error);
      const response: UploadResponse = {
        success: false,
        error: error instanceof Error ? error.message : "حدث خطأ أثناء معالجة الملف",
      };
      res.status(500).json(response);
    }
  });

  return httpServer;
}
