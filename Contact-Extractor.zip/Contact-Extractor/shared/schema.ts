import { z } from "zod";

export const contactSchema = z.object({
  id: z.string(),
  name: z.string(),
  phone: z.string(),
});

export type Contact = z.infer<typeof contactSchema>;

export const extractedDataSchema = z.object({
  contacts: z.array(contactSchema),
  fileName: z.string(),
  extractedAt: z.string(),
});

export type ExtractedData = z.infer<typeof extractedDataSchema>;

export const uploadResponseSchema = z.object({
  success: z.boolean(),
  data: extractedDataSchema.optional(),
  error: z.string().optional(),
});

export type UploadResponse = z.infer<typeof uploadResponseSchema>;
