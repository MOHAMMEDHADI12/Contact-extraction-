# Overview

This is an Arabic-language phone number extractor application ("مستخرج أرقام الجوالات"). Users upload files in various formats (TXT, CSV, PDF, DOC, DOCX, XLS, XLSX, JSON, XML, HTML), and the system extracts valid phone numbers with a focus on Saudi Arabian phone formats. Extracted contacts can be copied to clipboard or sent via WhatsApp.

## Recent Changes (January 2026)
- Implemented file upload and extraction functionality
- Added smart extraction for structured data (CSV/Excel) with column detection
- Added WhatsApp integration for sending messages to contacts
- Added bulk message sending feature
- Added dark/light theme toggle
- Fixed ESM module import issues for pdf-parse and mammoth

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Build Tool**: Vite with path aliases (@/ for client/src, @shared for shared types)
- **Language Direction**: RTL (Right-to-Left) for Arabic interface

## Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ES modules
- **File Processing**: Multer for file uploads with memory storage (10MB limit)
- **Document Parsing**:
  - pdf-parse for PDF files
  - mammoth for Word documents (DOC/DOCX)
  - exceljs for Excel spreadsheets
- **API Pattern**: REST endpoints under /api prefix

## Data Flow
1. User uploads file via `/api/extract` POST endpoint
2. Server parses file based on extension
3. Phone numbers extracted using regex patterns (Saudi + international formats)
4. Contacts returned with auto-generated IDs and extracted names
5. Frontend displays contacts with copy/WhatsApp integration

## Database Schema
- Uses Drizzle ORM with PostgreSQL dialect
- Schema defined in `shared/schema.ts` using Zod for validation
- Current storage is in-memory (MemStorage class) - database can be provisioned later
- Contact schema: id, name, phone fields

## Build System
- Development: `tsx server/index.ts` with Vite dev server middleware
- Production: Custom build script using esbuild for server, Vite for client
- Output: `dist/` directory with bundled server and static client files

# External Dependencies

## Document Processing
- **pdf-parse**: PDF text extraction
- **mammoth**: Word document conversion
- **exceljs**: Excel file parsing (replaced xlsx due to security CVEs)

## Database
- **PostgreSQL**: Primary database (via DATABASE_URL environment variable)
- **Drizzle ORM**: Database toolkit with drizzle-kit for migrations
- **connect-pg-simple**: Session storage (if sessions needed)

## Frontend Libraries
- **@tanstack/react-query**: Async state management
- **@radix-ui/***: Accessible UI primitives
- **wouter**: Client-side routing
- **lucide-react**: Icon library
- **date-fns**: Date utilities

## Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string